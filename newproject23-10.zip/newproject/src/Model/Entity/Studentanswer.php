<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * Studentanswer Entity.
 */
class Studentanswer extends Entity
{
	use TimezonedTrait;

}
