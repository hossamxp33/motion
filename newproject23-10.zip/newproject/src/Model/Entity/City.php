<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * City Entity.
 */
class City extends Entity
{
	use TimezonedTrait;

}
