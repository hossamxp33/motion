<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * Answer Entity.
 */
class Answer extends Entity
{
	use TimezonedTrait;

}
