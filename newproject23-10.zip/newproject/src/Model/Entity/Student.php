<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * Student Entity.
 */
class Student extends Entity
{
	use TimezonedTrait;

}
