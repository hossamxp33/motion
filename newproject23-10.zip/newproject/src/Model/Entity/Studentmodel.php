<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * Studentmodel Entity.
 */
class Studentmodel extends Entity
{
	use TimezonedTrait;

}
