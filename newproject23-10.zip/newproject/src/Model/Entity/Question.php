<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * Question Entity.
 */
class Question extends Entity
{
	use TimezonedTrait;

}
