<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * Model Entity.
 */
class Model extends Entity
{
	use TimezonedTrait;

}
