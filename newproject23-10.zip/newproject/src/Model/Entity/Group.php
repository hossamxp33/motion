<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Alaxos\Model\Entity\TimezonedTrait;

/**
 * Group Entity.
 */
class Group extends Entity
{
	use TimezonedTrait;

}
